# Sistema de Prevención frente a Desastres Naturales 2.0

Versión actualizada para la feria científica.

## Funciones principales
- Botones interactivos para terremoto, tsunami, incendio forestal, lluvias intensas, inundación, aluvión, volcán y tormenta.
- Selector de riesgo cuando el usuario indica que existe una amenaza en su zona.
- Información sobre parámetros de riesgo, cuándo evacuar, dónde acudir y cómo cuidarse.
- Fecha, hora y clima de referencia para Chillán mediante Open-Meteo.
- Bootstrap y Font Awesome.
- Números de emergencia y enlaces oficiales.

La evaluación es educativa y no reemplaza alertas ni instrucciones oficiales.
