// =========================================================
// SISTEMA DE PREVENCIÓN FRENTE A DESASTRES NATURALES 2.0
// JavaScript
// =========================================================

// ---------------------------------------------------------
// FECHA Y HORA
// ---------------------------------------------------------

function actualizarFechaHora() {
    const ahora = new Date();

    const fecha = ahora.toLocaleDateString("es-CL", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
    });

    const hora = ahora.toLocaleTimeString("es-CL");

    document.getElementById("fechaActual").textContent = fecha;
    document.getElementById("horaActual").textContent = hora;
}

actualizarFechaHora();
setInterval(actualizarFechaHora, 1000);


// ---------------------------------------------------------
// CLIMA - OPEN-METEO
// Referencia: Chillán, Chile
// ---------------------------------------------------------

async function actualizarClima() {

    const resultado = document.getElementById("climaResultado");

    resultado.innerHTML = `
        <span>
            <i class="fa-solid fa-spinner fa-spin"></i>
            Consultando información...
        </span>
    `;

    try {

        const latitud = -36.6066;
        const longitud = -72.1034;

        const url =
            `https://api.open-meteo.com/v1/forecast?latitude=${latitud}` +
            `&longitude=${longitud}` +
            `&current=temperature_2m,relative_humidity_2m,wind_speed_10m` +
            `&timezone=America%2FSantiago`;

        const respuesta = await fetch(url);

        if (!respuesta.ok) {
            throw new Error("No se pudo consultar el clima.");
        }

        const datos = await respuesta.json();

        const temperatura = datos.current.temperature_2m;
        const humedad = datos.current.relative_humidity_2m;
        const viento = datos.current.wind_speed_10m;

        resultado.innerHTML = `
            <div>
                <div class="fs-3 fw-bold mb-2">
                    ${temperatura} °C
                </div>

                <div>
                    <i class="fa-solid fa-droplet"></i>
                    Humedad: ${humedad}%
                </div>

                <div>
                    <i class="fa-solid fa-wind"></i>
                    Viento: ${viento} km/h
                </div>
            </div>
        `;

    } catch (error) {

        resultado.innerHTML = `
            <div class="text-danger">
                <i class="fa-solid fa-circle-exclamation"></i>
                No fue posible obtener el clima en este momento.
            </div>
        `;
    }
}


// ---------------------------------------------------------
// EVALUACIÓN DEL RIESGO
// ---------------------------------------------------------

function analizarRiesgo() {

    const amenaza = Number(document.getElementById("pregunta1").value);
    const alerta = Number(document.getElementById("pregunta2").value);
    const plan = Number(document.getElementById("pregunta3").value);

    const puntaje = amenaza + alerta + plan;

    const resultado = document.getElementById("resultadoRiesgo");

    // Apagar todas las luces
    document.getElementById("luzVerde").className = "luz";
    document.getElementById("luzAmarilla").className = "luz";
    document.getElementById("luzRoja").className = "luz";
    document.getElementById("luzNegra").className = "luz";

    if (puntaje <= 1) {

        resultado.innerHTML = `
            <i class="fa-solid fa-circle-check"></i>
            Riesgo educativo: BAJO
            <br>
            <small>Continúa preparado y atento a la información oficial.</small>
        `;

        document.getElementById("luzVerde").classList.add("activa-verde");

    } else if (puntaje <= 2) {

        resultado.innerHTML = `
            <i class="fa-solid fa-triangle-exclamation"></i>
            Riesgo educativo: MEDIO
            <br>
            <small>Revisa tu plan familiar y mantente informado.</small>
        `;

        document.getElementById("luzAmarilla").classList.add("activa-amarilla");

    } else if (puntaje <= 3) {

        resultado.innerHTML = `
            <i class="fa-solid fa-circle-exclamation"></i>
            Riesgo educativo: ALTO
            <br>
            <small>Presta atención a las instrucciones de las autoridades.</small>
        `;

        document.getElementById("luzRoja").classList.add("activa-roja");

    } else {

        resultado.innerHTML = `
            <i class="fa-solid fa-skull-crossbones"></i>
            Riesgo educativo: MUY ALTO
            <br>
            <small>Busca información oficial y sigue las instrucciones de emergencia.</small>
        `;

        document.getElementById("luzNegra").classList.add("activa-negra");
    }
}
\n\n// =========================================================\n// SELECTOR INTERACTIVO DE RIESGOS\n// =========================================================\n\nconst informacionRiesgos = {\n    terremoto: {\n        titulo: "Terremoto", icono: "fa-house-crack",\n        parametros: [\n            "Movimiento sísmico fuerte o prolongado.",\n            "Daños visibles en estructuras u objetos que puedan caer.",\n            "Caída de vidrios, muebles u otros elementos.",\n            "Alertas o instrucciones emitidas por las autoridades."\n        ],\n        evacuar: [\n            "Si una autoridad indica evacuar.",\n            "Si la construcción presenta daños o peligro de derrumbe.",\n            "Si existe un peligro secundario como incendio, fuga o cables caídos.",\n            "Si estás en una zona costera y existen condiciones de tsunami."\n        ],\n        lugar: [\n            "Zona de seguridad establecida para tu sector.",\n            "Espacios abiertos alejados de edificios, postes y cables.",\n            "En caso de tsunami, sigue la ruta oficial hacia una zona segura."\n        ],\n        cuidados: [\n            "Agáchate, cúbrete y afírmate durante el movimiento.",\n            "Aléjate de ventanas y objetos que puedan caer.",\n            "No uses ascensores.",\n            "Mantente atento a réplicas e instrucciones oficiales."\n        ]\n    },\n    tsunami: {\n        titulo: "Tsunami", icono: "fa-water",\n        parametros: [\n            "Terremoto fuerte o prolongado en una zona costera.",\n            "Cambio repentino e inusual del nivel del mar.",\n            "Retiro o avance anormal del mar.",\n            "Alerta o instrucción oficial de evacuación."\n        ],\n        evacuar: [\n            "Si sientes un terremoto fuerte o prolongado estando en la costa.",\n            "Si observas señales naturales de tsunami.",\n            "Si existe una alerta o instrucción oficial.",\n            "No esperes a ver una ola para comenzar a evacuar."\n        ],\n        lugar: [\n            "Zona de seguridad de tsunami señalizada.",\n            "Terreno elevado o sector definido por las autoridades.",\n            "Sigue las rutas oficiales de evacuación.",\n            "Aléjate de playas, desembocaduras y sectores bajos."\n        ],\n        cuidados: [\n            "Evacúa caminando cuando sea posible.",\n            "No regreses a la costa hasta recibir autorización oficial.",\n            "Lleva solo elementos esenciales.",\n            "Ayuda a quienes necesiten apoyo sin ponerte en peligro."\n        ]\n    },\n    incendio: {\n        titulo: "Incendio forestal", icono: "fa-fire",\n        parametros: [\n            "Fuego visible en vegetación o bosque.",\n            "Humo intenso o avance del fuego hacia sectores habitados.",\n            "Viento fuerte que favorezca la propagación.",\n            "Alerta o instrucción de evacuación."\n        ],\n        evacuar: [\n            "Cuando las autoridades ordenen evacuar.",\n            "Si el fuego o humo se aproxima y existe una ruta segura.",\n            "Si tu zona está directamente amenazada.",\n            "No esperes a que el fuego llegue a tu vivienda."\n        ],\n        lugar: [\n            "Punto de encuentro o zona de seguridad definida.",\n            "Sector alejado del fuego y del humo.",\n            "Rutas indicadas por las autoridades.",\n            "No bloquees caminos utilizados por vehículos de emergencia."\n        ],\n        cuidados: [\n            "Aléjate del humo.",\n            "No intentes combatir un incendio grande por tu cuenta.",\n            "No regreses hasta recibir autorización.",\n            "Informa rápidamente si detectas un incendio."\n        ]\n    },\n    lluvias: {\n        titulo: "Lluvias intensas", icono: "fa-cloud-rain",\n        parametros: [\n            "Precipitaciones intensas o persistentes.",\n            "Avisos meteorológicos o alertas oficiales.",\n            "Aumento de caudales o acumulación de agua.",\n            "Saturación del suelo y riesgo de deslizamientos o inundaciones."\n        ],\n        evacuar: [\n            "Si la autoridad ordena evacuar.",\n            "Si tu vivienda o sector comienza a inundarse.",\n            "Si existe peligro de deslizamiento o aluvión.",\n            "Si las rutas habituales dejan de ser seguras."\n        ],\n        lugar: [\n            "Zona de seguridad indicada por las autoridades.",\n            "Sectores altos cuando corresponda.",\n            "Refugios o puntos de encuentro establecidos.",\n            "Evita quebradas, ríos y zonas bajas."\n        ],\n        cuidados: [\n            "Evita salir innecesariamente.",\n            "No cruces calles o cauces con agua en movimiento.",\n            "Mantente informado mediante canales oficiales.",\n            "Ten lista tu mochila de emergencia."\n        ]\n    },\n    inundacion: {\n        titulo: "Inundación", icono: "fa-house-flood-water",\n        parametros: [\n            "Acumulación de agua en calles, viviendas o terrenos.",\n            "Desborde de ríos, canales u otros cauces.",\n            "Lluvias intensas y persistentes.",\n            "Alertas o instrucciones de autoridades."\n        ],\n        evacuar: [\n            "Si el agua ingresa a la vivienda y aumenta rápidamente.",\n            "Si existe riesgo para la vida o la estructura.",\n            "Si la autoridad ordena evacuar.",\n            "Antes de que las rutas queden bloqueadas."\n        ],\n        lugar: [\n            "Zonas altas y seguras.",\n            "Puntos de encuentro oficiales.",\n            "Sectores alejados de cauces y corrientes.",\n            "Nunca busques refugio dentro de un cauce."\n        ],\n        cuidados: [\n            "Nunca cruces agua en movimiento a pie o en vehículo.",\n            "Aléjate de cables eléctricos caídos.",\n            "Evita el contacto con agua posiblemente contaminada.",\n            "Sigue instrucciones oficiales antes de regresar."\n        ]\n    },\n    aluvion: {\n        titulo: "Aluvión", icono: "fa-mountain",\n        parametros: [\n            "Lluvias intensas en zonas de montaña o quebradas.",\n            "Aumento repentino del caudal o turbiedad del agua.",\n            "Movimiento de barro, rocas y sedimentos.",\n            "Alertas oficiales por amenaza de remoción en masa."\n        ],\n        evacuar: [\n            "Si las autoridades ordenan evacuar.",\n            "Si se observan señales de barro, rocas o agua desplazándose.",\n            "Si estás cerca de una quebrada o cauce amenazado.",\n            "Evacúa antes de que la corriente bloquee la salida."\n        ],\n        lugar: [\n            "Sectores altos y fuera de quebradas y cauces.",\n            "Zona de seguridad indicada oficialmente.",\n            "Rutas de evacuación señalizadas.",\n            "Aléjate de laderas inestables."\n        ],\n        cuidados: [\n            "No intentes observar o grabar el aluvión.",\n            "Aléjate inmediatamente de quebradas.",\n            "No regreses hasta recibir autorización.",\n            "Mantén comunicación con familiares y autoridades."\n        ]\n    },\n    volcan: {\n        titulo: "Actividad volcánica", icono: "fa-volcano",\n        parametros: [\n            "Cambios en la actividad informados oficialmente.",\n            "Emisión de ceniza, gases u otros materiales.",\n            "Alertas o niveles establecidos por organismos especializados.",\n            "Amenaza para sectores ubicados en áreas de peligro."\n        ],\n        evacuar: [\n            "Cuando la autoridad competente lo indique.",\n            "Si tu zona se encuentra dentro de un área que deba ser evacuada.",\n            "Si existe peligro inmediato por flujos, ceniza u otros fenómenos.",\n            "Sigue las rutas oficiales."\n        ],\n        lugar: [\n            "Zona de seguridad establecida para el volcán.",\n            "Sectores fuera de las áreas de peligro.",\n            "Puntos de encuentro oficiales.",\n            "Aléjate de cauces que puedan transportar materiales volcánicos."\n        ],\n        cuidados: [\n            "Mantente informado por organismos oficiales.",\n            "Protege ojos y vías respiratorias frente a ceniza según las recomendaciones.",\n            "Cierra puertas y ventanas cuando corresponda.",\n            "No te acerques al volcán para observarlo."\n        ]\n    },\n    tormenta: {\n        titulo: "Tormenta", icono: "fa-cloud-bolt",\n        parametros: [\n            "Actividad eléctrica y presencia de rayos.",\n            "Viento fuerte.",\n            "Lluvia intensa o granizo.",\n            "Avisos y alertas meteorológicas."\n        ],\n        evacuar: [\n            "Si existe peligro directo para las personas o la estructura.",\n            "Si las autoridades ordenan desplazarse a una zona segura.",\n            "Si estás en un lugar abierto durante actividad eléctrica intensa.",\n            "Busca refugio antes de que las condiciones empeoren."\n        ],\n        lugar: [\n            "Interior de una construcción segura.",\n            "Alejado de árboles aislados, postes y estructuras inestables.",\n            "No permanezcas en playas, canchas o zonas abiertas durante rayos.",\n            "Sigue las recomendaciones oficiales."\n        ],\n        cuidados: [\n            "Permanece bajo techo durante la actividad eléctrica.",\n            "Aléjate de ventanas.",\n            "Evita tocar instalaciones eléctricas innecesariamente.",\n            "Espera a que pase la tormenta antes de salir."\n        ]\n    }\n};\n\nfunction llenarLista(id, elementos) {\n    const lista = document.getElementById(id);\n    lista.innerHTML = "";\n    elementos.forEach(texto => {\n        const li = document.createElement("li");\n        li.textContent = texto;\n        lista.appendChild(li);\n    });\n}\n\nfunction mostrarSelectorRiesgo() {\n    document.getElementById("selectorRiesgo").classList.remove("d-none");\n    document.getElementById("resultadoRiesgoTipo").innerHTML =\n        '<i class="fa-solid fa-list-check"></i> Selecciona el tipo de riesgo que existe en tu zona.';\n    document.getElementById("selectorRiesgo").scrollIntoView({ behavior: "smooth", block: "center" });\n}\n\nfunction sinRiesgo() {\n    document.getElementById("selectorRiesgo").classList.add("d-none");\n    document.getElementById("informacionRiesgo").classList.add("d-none");\n    document.getElementById("resultadoRiesgoTipo").innerHTML =\n        '<i class="fa-solid fa-circle-check text-success"></i> No se ha indicado un riesgo. Mantente preparado y atento a la información oficial.';\n}\n\nfunction seleccionarRiesgo(tipo) {\n    const riesgo = informacionRiesgos[tipo];\n    if (!riesgo) return;\n\n    document.getElementById("selectorRiesgo").classList.remove("d-none");\n    document.getElementById("informacionRiesgo").classList.remove("d-none");\n    document.getElementById("tituloRiesgo").textContent = riesgo.titulo;\n    document.getElementById("iconoRiesgo").innerHTML = `<i class="fa-solid ${riesgo.icono}"></i>`;\n\n    llenarLista("parametrosRiesgo", riesgo.parametros);\n    llenarLista("evacuacionRiesgo", riesgo.evacuar);\n    llenarLista("lugarRiesgo", riesgo.lugar);\n    llenarLista("cuidadosRiesgo", riesgo.cuidados);\n\n    document.getElementById("resultadoRiesgoTipo").innerHTML =\n        `<i class="fa-solid fa-triangle-exclamation"></i> Riesgo seleccionado: <strong>${riesgo.titulo}</strong>. Revisa la información antes de actuar.`;\n\n    document.getElementById("informacionRiesgo").scrollIntoView({ behavior: "smooth", block: "start" });\n}\n